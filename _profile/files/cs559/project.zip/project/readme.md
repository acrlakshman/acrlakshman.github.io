Project-3
Name: China Rama Lakshman Anumolu
Course: CS559

Features:
=========
-Ribbons
========
	- Constructed using cubic Bezier polynomial. Four points on a unstiched elongated cylinder are considered and the intermediate points are obtained using De Casteljau's algorithm.
-Infinite ribbons
=================
	- Constructed using multiple ribbons. Initially starts with specified number of ribbons maintained using vector class. Depending on the proximity of the camera the ribbons from vector will be popped and pushed continously to make an infinite effect.
-Camera
=======
	- A Quaternion based camera is implemented and can be steered through the scene both in the pause and play mode.
-Textures
=========
	- Screen space, eye space and model space procedural textures are demonstrated with spheres that continuously swim through the scene. Image based texture is also demonstrated.
-Objects
========
	- Ribbons and spheres are used for this project and some of them have special features as follows:
	1) Transparency can be changed with 'b' key press.
	2) Texture can be toggled with 't' key press.
	3) Some objects can be accelerated with left mouse click.
	4) Some objects can change textures with mouse hovering on them.
	5) Gaussian blur is demonstrated on some objects which are rendered using frame buffer objects
	6) Objects swim through the scene with varying speeds by holding 'i' and 'o' keys that increase and decrease speeds respectively.
-Mouse
======
	- Some objects are detected by mouse hovering and moved by  left mouse cliks. This is achieved by ray hit algorithm, by connecting a line segment (ray) from some point on the screen space (where a mouse is located) and obtaining the corresponding world space coordinates and computing whether that line segment is intersected by any bounding box of the objects. Among all detected objects nearest one will be selected.

Keyboard and Mouse roles
========================
	- 'p': (pause mode)
		    1) In this mode, camera can be steered through the scene with left and right keys.
		    2) Some objects which can be detected by mouse can be given a velocity to go away from the scene.
	- '3': (camera pause)
			1) Objects will continue to move in this mode, but camera stops and can be steered through the scene.
	- 'i': (speed up)
			1) Speed up the entire scene, except the objects that can be detected by mouse.
	- 'o': (slow down)
			1) Slow down the entire scene, except the objects that can be detected by the mouse.
	- 't': (toggle texture)
			1) Texture rendering is toggled on some objects.
	- 'b': (transparency)
			1) Change transparency of some objects with this key.
	- 'l': (multiple lights)
			1) Some objects with be rendered with multiple lights (maximum 3).
	- 'w': (wireframe mode)
			1) Changes all objects to wireframe mode.