Please make sure that dependency information in make files is correct.
