/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | 
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2012 Lakshman Anumolu, Imaduddin Ahmed
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is a derivative work of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    smokeSim_OpenFOAM

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include <cstdlib>
#include <fstream>
#include "MULES_User.H"
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "setRootCase.H"

    #include "createTime.H"
    #include "createMesh.H"
    #include "createFields.H"
    #include "initContinuityErrs.H"

    #include "readTimeControls.H"
    #include "CourantNo.H"
    #include "setInitialDeltaT.H"

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info<< "\nStarting time loop\n" << endl;

    while (runTime.loop())
    {
        Info<< "Time = " << runTime.timeName() << nl << endl;

        #include "readPISOControls.H"
        #include "CourantNo.H"
	#include "setDeltaT.H"

	// --- Computing force term
	/* buoyancy force */
  	forAll(f_buoy,cellI){
        f_buoy[cellI]=-alpha_f.value()*density[cellI]*vector(0,1,0) + beta.value()*(temperature[cellI]-T_amb.value())*vector(0,1,0);
        }

        /* vorticity confinement force */
        volVectorField omega=fvc::curl(U);
        volVectorField eta=fvc::grad(mag(omega));
        dimensionedScalar OneByTime("OneByTime",dimless/dimTime,1.);
        dimensionedScalar delta_N("delta_N",1e-8/(pow(average(mesh.V()),1./3.)/OneByTime));
        volVectorField N=eta/(mag(eta)+delta_N);

	volVectorField Nomega=N^omega;

	volVectorField f_conf
        (
            IOobject
            (
                "f_conf",
                runTime.timeName(),
                mesh,
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
            epsilon_f_conf*pow(average(mesh.V()),1./3.)*(N^omega)
        );
        f_conf.dimensions()=dimLength/dimTime/dimTime;

        f_buoy+=f_conf;

        fvVectorMatrix UEqn
        (
            fvm::ddt(U)
          + fvm::div(phi, U)
	  //- f_buoy
          - fvm::laplacian(nu, U)
        );

        solve(UEqn == -fvc::grad(p));

        // --- PISO loop

        for (int corr=0; corr<nCorr; corr++)
        {
            volScalarField rAU(1.0/UEqn.A());
            surfaceScalarField rAUf=fvc::interpolate(rAU);

            U = rAU*UEqn.H();
            phi = (fvc::interpolate(U) & mesh.Sf())// + (fvc::interpolate(f_buoy)&mesh.Sf())*rAUf
                + fvc::ddtPhiCorr(rAU, U, phi);

            adjustPhi(phi, U, p);

            for (int nonOrth=0; nonOrth<=nNonOrthCorr; nonOrth++)
            {
                fvScalarMatrix pEqn
                (
                    fvm::laplacian(rAU, p) == fvc::div(phi)
                );

                pEqn.setReference(pRefCell, pRefValue);
                pEqn.solve();

                if (nonOrth == nNonOrthCorr)
                {
                    phi -= pEqn.flux();
                }
            }

            #include "continuityErrs.H"

            U -= rAU*fvc::grad(p);
            U.correctBoundaryConditions();
        }

	// Update density
        #include "Update_Density.H"

	// Store density field
	if (runTime.timeName()==tWriteInterval) {
		#include "StoreDensityToRender.H"
		#include "StoreDensityToRender_pt2.H"
		#include "StoreDensityToRender_pt3.H"
		tWriteInterval+=writeinterval;
	}

        // Update temperature
        #include "Update_Temperature.H"

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
